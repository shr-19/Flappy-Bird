<h1> Flappy Bird </h2>
In this project, we have created a game using the “Pygame” module in python.
The game is a side-scroller where the player controls a bird, attempting to fly between columns of green pipes without hitting them, and scores for the same.

